const url = (endpoint) =>{
    return `https://elegantapp.pythonanywhere.com${endpoint}`;
}


const getSession = () => {
    const token = localStorage.getItem("token");
    return token;
}

const setSession  = (token) => {
    localStorage.setItem("token", token);
    return token;
}


class ShopRequest{
    constructor(endpoint){
        this.token = getSession();
        if (!this.token){throw new Error("No token found");}
        this.url = url(endpoint);
    }

    async get(){
        const headers = new Headers();
        headers.append("Authorization", `Token ${this.token}`);
        const request = new Request(this.url, {
            method: "GET",
            headers: headers,
            mode: "cors"
        });
        return await fetch(request);
    }


    async post(data){
        const headers = new Headers();
        headers.append("Authorization", `Token ${this.token}`);
        headers.append("Content-Type", "application/json");
        const request = new Request(this.url, {
            method: "POST",
            headers: headers,
            mode: "cors",
            body: JSON.stringify(data)
        });
        return await fetch(request);
    }

    async postMedia(form_data){
        const headers = new Headers();
        headers.append("Authorization", `Token ${this.token}`);
        const request = new Request(this.url, {
            method: "POST",
            headers: headers,
            mode: "cors",
            body: form_data
        });
        return await fetch(request);
    }

    async patchMedia(form_data){
        const headers = new Headers();
        headers.append("Authorization", `Token ${this.token}`);
        const request = new Request(this.url, {
            method: "PATCH",
            headers: headers,
            mode: "cors",
            body: form_data
        });
        return await fetch(request);
    }

    async delete(){
        const headers = new Headers();
        headers.append("Authorization", `Token ${this.token}`);
        const request = new Request(this.url, {
            method: "DELETE",
            headers: headers,
            mode: "cors"
        });
        return await fetch(request);
    }
}

const request = (endpoint) => {
    return new ShopRequest(endpoint);
}


export {
    url,
    getSession,
    setSession,
    request
}