import { create } from 'zustand'

const useAuth = create(set => ({
    session: null,
    setSession: (token) => {
        localStorage.setItem("token", token);
        set({session: token});
    }
}))

const useCartItems = create(set => ({
    cartItems: [],
    setCartItems : (items) =>{
        set({
            cartItems:items
        })
    }
}))


export {
    useAuth,
    useCartItems
}