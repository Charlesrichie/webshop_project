import React from 'react'
import { useState } from 'react'
import { FileInput } from '@mantine/core';
import { request } from '../../utils';
import {toast} from 'react-hot-toast'

const AddProduct = ({setGlobalProduct, openModal}) => {
    const initial_props = {
        name: "",
        description: "",
        price: "",
    }
    const [form, setForm] = useState(initial_props);

    const [file, setFile] = useState(null);

    const handleSubmit = async (e) => {        
        e.preventDefault();
        const toastId = toast.loading("Creating Product");
        try{
            const formData = new FormData();

            formData.append("name", form.name);
            formData.append("description", form.description);
            formData.append("price", form.price);
            formData.append("thumbnail", file);
            const response = await request("/api/shop/items/").postMedia(formData);
            
            if (!response.ok) {
                const data = await response.json();
                for (const key in data) {
                    toast.dismiss(toastId);
                    toast.error(data[key]);
                }
                return;
            }
            
            const data = await response.json();
            toast.dismiss(toastId);
            toast.success("Product Created");
            setGlobalProduct(prev => prev.map(item => item.id === data.id ? data : item));
            setForm(initial_props)
            setFile(null);
            openModal(false);
        }catch(err){
            console.log(err);
            toast.dismiss(toastId);
            toast.error("Something went wrong");
        }
    }

    return (
    <div>
        <form onSubmit={handleSubmit}>
            <div className='mb-3'>
                <label htmlFor="name" className="text-[.8rem] font-bold opacity-80">
                    NAME
                </label>
                <input 
                    type="text" 
                    id="name" 
                    name="name"
                    value={form.name}
                    onChange={(e) => setForm({...form, name: e.target.value})}
                    className="border rounded border-[#0e333d] p-2 w-full px-3"
                    required
                    />
            </div>
            <div className='mb-3'>
                <label htmlFor="description" className='text-[.8rem] font-bold opacity-80'>
                    DESCRIPTION
                </label>
                <input 
                    type="text" 
                    name="description" 
                    id="description"
                    value={form.description}
                    onChange={(e) => setForm({...form, description: e.target.value})}
                    className="border rounded border-[#0e333d] p-2 w-full px-3"
                    required
                />
            </div>
            <div className='mb-3'>
                <label htmlFor="price" className='text-[.8rem] font-bold opacity-80'>
                    PRICE (€)
                </label>
                <input 
                    type="number" 
                    name="price" 
                    id="price"
                    value={form.price}
                    onChange={(e) => setForm({...form, price: e.target.value})}
                    className="border rounded border-[#0e333d] p-2 w-full px-3"
                    required
                />
            </div>
            <div className='mb-3'>
                <label htmlFor="thumbnail" className='text-[.8rem] font-bold opacity-80'>
                    THUMBNAIL
                </label>
                <FileInput 
                    placeholder="Choose Image" 
                    accept="image/png,image/jpeg"
                    size='md'
                    value={file}
                    onChange={setFile}
                    required={true}
                    />
            </div>
            <div>
                <button 
                    type="submit" 
                    className='bg-[#0e333d] text-white px-4 py-2 font-bold rounded'
                >Add Product</button>
            </div>
        </form> 
    </div>
  )
}

export default AddProduct
