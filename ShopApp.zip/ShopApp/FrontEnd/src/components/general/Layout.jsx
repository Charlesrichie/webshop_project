import Footer from "./Footer"
import Header from "./Header"
import { Outlet } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

const Layout = () => {
    const navigate = useNavigate();
    useEffect(
        () => {
          // if the / route is hit, redirect to /shop
          if (window.location.pathname === "/"){
            navigate('/shop');
          }
        }
    , [navigate]);
    return (
    <div className='max-w-[86rem] m-auto'>
      <div className="bg-[#fff9f4] min-h-screen">
        <Header />
          <div className='px-4 pt-[5rem] py-7 md:px-12'>
            <Outlet />
          </div>
        <Footer />
      </div>
    </div>
    )
}


export default Layout