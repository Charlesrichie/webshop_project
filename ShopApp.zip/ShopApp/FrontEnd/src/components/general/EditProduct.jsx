import { FileInput } from '@mantine/core'
import React from 'react'
import { useState } from 'react'
import { toast } from 'react-hot-toast'
import { request } from '../../utils'

export const EditProduct = ({product, setGlobalProduct, openModal}) => {
    const [form, setForm] = useState(product)
    const [file, setFile] = useState(null)

    const handleSubmit = async (e)=>{
        e.preventDefault()
        const toastId = toast.loading("Updating...")
        try{   
            const formData = new FormData();
            formData.append("name", form.name);
            formData.append("description", form.description);
            formData.append("price", form.price);
            if (file){
                formData.append("thumbnail", file);
            }
            
            const response = await request(`/api/shop/items/${product.id}/`).patchMedia(formData)
            
            if (!response.ok){
                const data = await response.json();
                for (const key in data) {
                    toast.dismiss(toastId);
                    toast.error(data[key]);
                }
                return;
            }
            const data = await response.json()
            toast.dismiss(toastId);
            toast.success("Updated  Successfull");
            setGlobalProduct(prev => prev.map(item => item.id === data.id ? data : item))
            openModal(false)
        }catch(err){
            console.log(err)
            toast.dismiss(toastId);
            toast.error("Something went wrong");
        }
    }


    const deleteProduct = async() =>{
        const toastId = toast.loading("Deleting...")
        try{
            const response = await request(`/api/shop/items/${product.id}/`).delete()
            if (!response.ok){
                toast.error("Something went wrong", {id: toastId})
                return;
            }
            toast.success("Deleted Successfull", {id: toastId})
            setGlobalProduct(prev => prev.filter(item => item.id !== product.id))
            openModal(false)
        }catch(err){
            console.log(err)
            toast.error("Something went wrong", {id: toastId})
        }
    }

  return <div>
  <form onSubmit={handleSubmit}>
      <div className='mb-3'>
          <label htmlFor="name" className="text-[.8rem] font-bold opacity-80">
              NAME
          </label>
          <input 
              type="text" 
              id="name" 
              name="name"
              value={form.name}
              onChange={(e) => setForm({...form, name: e.target.value})}
              className="border rounded border-[#0e333d] p-2 w-full px-3"
              />
      </div>
      <div className='mb-3'>
          <label htmlFor="description" className='text-[.8rem] font-bold opacity-80'>
              DESCRIPTION
          </label>
          <input 
              type="text" 
              name="description" 
              id="description"
              value={form.description}
              onChange={(e) => setForm({...form, description: e.target.value})}
              className="border rounded border-[#0e333d] p-2 w-full px-3"
          />
      </div>
      <div className='mb-3'>
          <label htmlFor="price" className='text-[.8rem] font-bold opacity-80'>
              PRICE (€)
          </label>
          <input 
              type="number" 
              name="price" 
              id="price"
              value={form.price}
              onChange={(e) => setForm({...form, price: e.target.value})}
              className="border rounded border-[#0e333d] p-2 w-full px-3"
          />
      </div>
      <div className='mb-3'>
          <label htmlFor="thumbnail" className='text-[.8rem] font-bold opacity-80'>
              THUMBNAIL
          </label>
          <FileInput 
              placeholder="Change Image" 
              accept="image/png,image/jpeg"
              size='md'
              value={file}
              onChange={setFile}
              />
      </div>
      <div className='flex items-center justify-between'>
          <button 
              type="submit" 
              className='bg-[#0e333d] text-white px-4 py-2 font-bold rounded'
          >Save</button>
          <button 
              type="button" 
              onClick={deleteProduct}
              className='bg-red-500 text-white px-4 py-2 font-bold rounded'
          >Delete</button>
      </div>
  </form> 
</div>
}
