import { Modal } from "@mantine/core"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useAuth, useCartItems } from "../../store"
import { EditProduct } from "./EditProduct"

const Product = ({product, hideCart, editable, setGlobalProduct}) => {
    const setCartItems = useCartItems(state => state.setCartItems)
    const cartItems = useCartItems(state => state.cartItems)
    const itemExists = cartItems.find(item => item.id === product.id)
    const [opened, setOpened] = useState(false)
    const session = useAuth(state => state.session)
    const navigate = useNavigate()
    const format_date_added = (date) => {
        if (!date) return ""
        const date_added = new Date(date)
        const date_added_formatted = date_added.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric"
        })
        return date_added_formatted
    }
    
    const addToCart = (item) =>{
        if (itemExists) return
        if (!session) {
            navigate('/login')
            return
        }
        const newCartItems = [...cartItems, item]
        setCartItems(newCartItems)
    }

    const editProduct = ()=>{
        setOpened(true)
    } 

    return (
        <div className="rounded-md min-h-[29rem] shadow-md overflow-hidden text-[#0e333d] bg-[#f6f6f6]">
            <img src={product?.thumbnail} alt={product?.name}  className="w-full h-[60%]"/>
            <div className="p-4 flex flex-col space-y-3 items-start my-3">
                <div className="flex w-full text-[1.1rem] font-bold items-center justify-between">
                    <span className="w-3/5 font-volkolak">{product?.name}</span>
                    <span>€ {product?.price}</span>
                </div>

                <p>{product.description}</p>
                <p>{format_date_added(product?.created_at)}</p>
                {!hideCart && 
                    <button 
                        disabled={itemExists}
                        onClick={() =>addToCart(product)}
                        className="border px-3 p-1 rounded-xl border-[#0e333d] disabled:opacity-50"
                    >Add to Cart
                    </button>
                }
                {
                    editable && <button 
                        onClick={() => editProduct()}
                        className="border px-3 p-1 rounded-xl border-[#0e333d] disabled:opacity-50"
                    >Edit
                    </button>
                }

            </div>
            <Modal
                opened={opened}
                onClose={() => setOpened(false)}
                title="Edit Product"
            >
                <EditProduct  
                    product={product}
                    openModal={setOpened}
                    setGlobalProduct={setGlobalProduct}
                />
            </Modal>
        </div>
    )
}


export const NoProduct = ({firstLoad}) => {
    return (
        <div className="flex items-center opacity-30 my-6 min-h-[13rem] justify-center">
            <h1 className="font-bold text-center text-xl font-volkolak mb-6">
                {firstLoad ? "Fetching Products..":  "No Products Found"}
            </h1>
        </div>
    )
}

export default Product