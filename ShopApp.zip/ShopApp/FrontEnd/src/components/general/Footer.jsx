import React from 'react'

const Footer = () => {
  return (
    <footer className="bg-[#0e333d] w-full text-white p-8 md:px-12">
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 justify-between">
                <div className="flex flex-col space-y-3">
                    <h4 className="font-volkolak text-4xl">Web Shop</h4>
                    <p>+1234 567 890</p>
                    <p>999 Ranchview Dr. Smart, California 00000</p>
                </div>
                <div className="flex flex-col space-y-3">
                    <p className="text-xl font-bold">About</p>
                    <p>Our Company</p>
                    <p>Our Products</p>
                    <p>Blog</p>
                </div>
                <div className="flex flex-col space-y-3">
                    <p className="text-xl font-bold">Support</p>
                    <p>FAQ</p>
                    <p>Terms & Conditions</p>
                    <p>Privacy Policy</p>
                </div>
            </div>
            <hr className="my-10 opacity-10" />
            <div className="flex justify-center items-center">
                <p>Copyright © 2022 Web SHop | All rights reserved.</p>
            </div>
    </footer>
  )
}

export default Footer
