import { TrashIcon } from '@heroicons/react/24/solid'
import React from 'react'
import { useCartItems } from '../../store'
import { ScrollArea } from '@mantine/core';
import { request } from '../../utils';
import { toast } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';


const CartItem = ({item})=>{
    const setCartItems = useCartItems(state => state.setCartItems)
    const cartItems = useCartItems(state => state.cartItems)
    const removeFromCart = (item_id) =>{
        const newCartItems = cartItems.filter(item => item.id !== item_id)
        setCartItems(newCartItems)
    }

    return <div className="border border-[#0e333d] my-4 rounded p-2">
        <div className='flex items-center justify-between'>
            <span>{item.name}</span>
            <span className='flex space-x-3 items-center'>
                <span>€ {item.price}</span>
                <TrashIcon 
                    onClick={()=> removeFromCart(item.id)}
                    className='text-red-500 h-4 w-4 cursor-pointer' 
                />
            </span>
        </div>   
        <div className=''>
            {item?.error && <p className='text-red-500 text-xs font-bold'>{item?.error}</p>}
        </div>
        
    </div>
}

const returnFirst = (arr) =>{
    let res;
    try{
        res = arr[0]
    } 
    catch{
        return null
    }
    return res
}


export const Cart = () => {
    const cartItems = useCartItems(state => state.cartItems)
    const setCartItems = useCartItems(state => state.setCartItems)
    const navigate = useNavigate()
    const pay = async ()=>{
        const toastId = toast.loading("Paying...")
        const response = await request("/api/shop/items/buy/").post(cartItems)
        
        if (!response.ok){
            const data = await response.json()
            
            // update the price of the item in the cart
            const newCartItems = cartItems.map(item => {
                try{
                    const error = data.find(error => returnFirst(error.id) === item.id)
                    if (error){
                        return {...item, price: returnFirst(error.price), error: returnFirst(error.message)}
                    }
                }catch{
                    return item
                }
                
                return item
            })
            setCartItems(newCartItems)
            toast.dismiss(toastId)
            return
        }
        toast.success("Successful", {id: toastId})
        // empty the cart
        setCartItems([])
        navigate("/myitems")
    }
    const allItemsPrice = cartItems?.reduce((acc, item) => acc + parseFloat(item.price), 0)
    
    return (
        <div>
             <ScrollArea style={{ height: 500 }}>
                {cartItems.map(item => <CartItem key={item.id} item={item} />)}
            </ScrollArea>
            <div className='flex justify-end items-center'>
                <button 
                    disabled={cartItems?.length < 1}
                    onClick={pay}
                    className='bg-[#0e333d] text-white px-3 p-2 rounded disabled:opacity-70'>
                    Pay <span className='font-bold'>€ {allItemsPrice}</span> 
                </button>
            </div>
        </div>
    )
}
