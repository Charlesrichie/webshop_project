import React, { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { useAuth, useCartItems } from '../../store';
import { shallow } from 'zustand/shallow';
import { Modal, Drawer} from '@mantine/core';
import { Bars3Icon, MagnifyingGlassIcon, ShoppingBagIcon } from '@heroicons/react/24/solid'
import { Cart } from './Cart';
import { MobileNav } from './MobileNav';


const Header = () => {
  const [session, setSession] = useAuth(
    state => [state.session, state.setSession],
    shallow
  )  
  const [cartItems, setCartItems] = useCartItems(
    state => [state.cartItems, state.setCartItems],
  )
  const [opened, setOpened] = useState(false);
  const [search, setSearch] = useState('')
  const [showCart, setShowCart] = useState(false)
  const [showNav, setShowNav] = useState(false)
  const navigate = useNavigate()
  let location = useLocation()
  const handleLogout = () => {
    setSession(null)
    localStorage.removeItem("token")
    navigate("/login")
  }
  useEffect(() => {
    const token = localStorage.getItem("token");
    if(token){
        setSession(token);
    }
  }, [setSession])
  
  const searchProducts = async () => {
    navigate(`/shop/${search}`)
    setOpened(false)
  }

  useEffect(
    ()=>{
      if(!session){
        setCartItems([])
      }
    }
  , [session, setCartItems])

  useEffect(
    ()=>{
      if (opened){
        setShowNav(false)
      }
    }
  , [opened])

  useEffect(
    () => {
      setShowNav(false)
      window.scrollTo(0, 0);
    },
    [location]
  )


  
  return (
    <header className='w-full px-4 md:px-12 fixed z-50 bg-[#fff9f4]'>
        <div className="flex items-center justify-between h-20">
        <Link to="/shop" className="text-[#0e333d] font-bold text-[2rem] font-volkolak">Web Shop</Link>
        <div className="hidden lg:flex items-center justify-between space-x-6">
              <Link to="/shop" className="text-[#0e333d] font-bold" >Home</Link>
              {session && <Link to="/myitems" className="text-[#0e333d] font-bold">My Items</Link>}
              {session && <Link to="/account" className="text-[#0e333d] font-bold">Account</Link>}
              {!session ? 
                <Link to="/login" className="text-[#0e333d] font-bold">Sign in</Link>
                : <button 
                    onClick={handleLogout}
                      className="text-[#0e333d] font-bold"
                    >Logout</button>
              }
            <MagnifyingGlassIcon 
                className='w-5 h-6 text-[#0e333d] cursor-pointer'
                onClick={setOpened.bind(true)}
              />
              <div onClick={setShowCart.bind(true)} className='cursor-pointer relative'>
                <ShoppingBagIcon 
                  className='w-5 h-6 text-[#0e333d]'
                />
                {cartItems?.length > 0 &&
                  <span className='absolute top-0 right-0 w-4 h-4 bg-[#f7b500] rounded-full text-white text-xs flex items-center justify-center'>{cartItems?.length}</span>
                }
           
              </div>
            

        </div>
        {/* menu nav */}
        <div className='flex md:hidden items-center space-x-5'>
            <div onClick={setShowCart.bind(true)} className='cursor-pointer relative'>
              <ShoppingBagIcon 
                className='w-5 h-6 text-[#0e333d]'
              />
              {cartItems?.length > 0 &&
                <span className='absolute top-0 right-0 w-4 h-4 bg-[#f7b500] rounded-full text-white text-xs flex items-center justify-center'>{cartItems?.length}</span>
              }
          
            </div>
            <Bars3Icon 
              className='text-[#0e333d] h-8 w-6 cursor-pointer' 
              onClick={()=> setShowNav(true)}
              />
        </div>
        </div>
        <Modal
          opened={opened}
          onClose={() => setOpened(false)}
          title="Search Products"
        >
        <div className='flex items-center border overflow-hidden border-[#0e333d] rounded-lg'>
          <input 
            type="text" 
            className='px-4 py-2 flex-1 border-none bg-none' 
            placeholder='Search Products'
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <button 
            disabled={!search}
            className='bg-[#0e333d] text-white px-4 py-2 disabled:opacity-50'
            onClick={searchProducts}
            >
              <MagnifyingGlassIcon 
                className='w-5 h-6  text-white'
              />
          </button>
        </div>
      </Modal>

      <Drawer
        opened={showCart}
        onClose={() => setShowCart(false)}
        title="Cart"
        padding="xl"
        size="xl"
        position='right'
      >
        <Cart />
      </Drawer>

      <Drawer
        opened={showNav}
        onClose={() => setShowNav(false)}
        padding="xl"
        size="xl"
        position='right'
      >
        <MobileNav setOpened={setOpened}/>
      </Drawer>

    </header>
  )
}

export default Header