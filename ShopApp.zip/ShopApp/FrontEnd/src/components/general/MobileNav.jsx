import React from 'react'
import { useAuth } from '../../store'
import { Link, useNavigate } from 'react-router-dom';
import { shallow } from 'zustand/shallow';


export const MobileNav = ({setOpened}) => {
    const [session, setSession] = useAuth(
        state => [state.session, state.setSession],
        shallow
      )  
    const navigate = useNavigate()
    const handleLogout = () => {
        setSession(null)
        localStorage.removeItem("token")
        navigate("/login")
      }

    return (
    <div className='flex flex-col space-y-6 items-center'>
        <Link to="/shop" className="text-[#0e333d] font-bold" >Home</Link>
              {session && <Link to="/myitems" className="text-[#0e333d] font-bold">My Items</Link>}
              {session && <Link to="/account" className="text-[#0e333d] font-bold">Account</Link>}
              {!session ? 
                <Link to="/login" className="text-[#0e333d] font-bold">Sign in</Link>
                : 
                <button 
                    onClick={handleLogout}
                      className="text-[#0e333d] font-bold"
                    >Logout
                </button>
              }
            <span 
                className='font-bold text-[#0e333d] cursor-pointer'
                onClick={setOpened.bind(true)}
              >
              Search
            </span>
    </div>
  )
}
