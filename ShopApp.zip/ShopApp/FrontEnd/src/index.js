import React from 'react';
import ReactDOM from 'react-dom/client';
import './static/css/index.css'

import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";

import Shop from './pages/shop';
import Login from './pages/login';
import Layout from './components/general/Layout';
import { Toaster } from 'react-hot-toast';
import SignUp from './pages/signup';
import MyItems from './pages/myitems';
import { Account } from './pages/account';

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        path: "/shop",
        element: <Shop />,
        children: [
          {
            path: "/shop/:search",
            element: <Shop />,
            
          }
        ]
      },
      {
        path: "/myitems",
        element: <MyItems />,
      },
      {
        path: "/account",
        element: <Account />
      },
      {
        path: "/login",
        element: <Login />,
      },
      {
        path : "/signup",
        element: <SignUp />
      }
    ]
  },
]);

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
    <Toaster
      position="top-right"
      reverseOrder={false}
    />
  </React.StrictMode>
);

