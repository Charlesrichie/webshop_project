import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import Product, { NoProduct } from "../components/general/Product"
import { getSession, url } from "../utils"
import { useAuth } from "../store"
import { Modal } from '@mantine/core';
import AddProduct from "../components/general/AddProduct"



const MyItems = ()=>{
    const navigate = useNavigate()
    const [myProducts, setMyProducts] = useState([])
    const [saleProduct, setSaleProduct] = useState([])
    const [soldProduct, setSoldProduct] = useState([])
    const [firstLoad, setFirstLoad] = useState(true)
    const session  = useAuth(state => state.session)
    const [opened, setOpened] = useState(false);
    useEffect(()=>{
        const session = getSession()
        if(!session){
            navigate('/login')
        }
        setFirstLoad(false)
    },[navigate])
    
    useEffect(() => {
        if (!session) return
        const fetchProducts = async (endpoint, setter) => {
            try{
                const res = await fetch(url(endpoint), 
                {
                    method: "get",
                    headers: new Headers({
                        "Authorization": session ? `Token ${session}` : "",
                        "Content-Type": "application/json"
                    })
                })
            
                const data = await res.json()
                if (res.status !== 200){
                    console.log(data)
                    return
                }
                const {results} = data
                setter(results)
            }catch(err){
                console.log(err)
            }
        }
        const purchased = fetchProducts(
            "/api/shop/history/purchased",
            setMyProducts
        )
        const sale = fetchProducts(
            "/api/shop/history/sale",
            setSaleProduct
        )
        const sold = fetchProducts(
            "/api/shop/history/sold",
            setSoldProduct
        )
        Promise.all([purchased, sale, sold])

    }, [firstLoad, session])


    return (
        <div>
            <div className="flex flex-col space-y-6 justify-center items-center">
                <h1 className="font-bold text-3xl font-volkolak">My Products</h1>
                <button onClick={setOpened.bind(true)} className="border px-6 p-1 rounded-2xl border-[#0e333d]">Add New</button>
            </div>
            <Modal
                opened={opened}
                onClose={() => setOpened(false)}
                title="Add New Product"
            >
                <AddProduct  
                    setGlobalProduct={setSaleProduct}
                    openModal={setOpened}
                />
            </Modal>


            {(myProducts.length > 0 || saleProduct.length > 0 || soldProduct.length > 0) ?
                
                <div className="my-4">
                {myProducts.length > 0 && <div className="border p-3">
                    <h3 className="font-bold font-volkolak">Purchased Products</h3>
                    {myProducts.length > 0 ? 
                        <div className="grid grid-cols14 md:grid-cols-4 my-4 gap-6">
                            {myProducts.map((product) => 
                                <Product 
                                    key={product.id} 
                                    product={product}
                                    hideCart={true}
                                    />)}
                        </div>
                        : <NoProduct firstLoad={firstLoad} />
                    }
                </div>}
                
                {saleProduct.length > 0 && <div className="border p-3">
                    <h3 className="font-bold font-volkolak">Products For Sale</h3>
                    {saleProduct.length > 0 ? 
                        <div className="grid grid-cols14 md:grid-cols-4 my-4 gap-6">
                            {saleProduct.map((product) => 
                            <Product 
                                key={product.id} 
                                product={product}
                                hideCart={true}
                                editable={true}
                                setGlobalProduct={setSaleProduct}
                                />)}
                        </div>
                        : <NoProduct firstLoad={firstLoad} />
                    }
                </div>}
                
                {soldProduct.length > 0 && <div className="border p-3">
                    <h3 className="font-bold font-volkolak">Products Sold</h3>
                    {soldProduct.length > 0 ? 
                        <div className="grid grid-cols14 md:grid-cols-4 my-4 gap-6">
                            {soldProduct.map((product) => 
                                <Product 
                                    key={product.id} 
                                    product={product}
                                    hideCart={true}
                                    />)}
                        </div>
                        : <NoProduct firstLoad={firstLoad} />
                    }
                </div>}
            </div>
            :
            <NoProduct firstLoad={firstLoad} />
            }
        </div>
        
    )
}

export default MyItems