import React from 'react'
import { useState } from 'react'
import { toast } from 'react-hot-toast'
import { useAuth } from '../store'
import { request } from '../utils'


export const Account = () => {
    const initials = {
        old_password: "",
        new_password: "",
        repeat_password: ""
    }
    const [form, setForm] = useState(initials)

    const setSession = useAuth(state => state.setSession)

    const disabled = form.new_password !== form.repeat_password
    
    const handleSubmit = async (e) =>{
        e.preventDefault()
        const toastId = toast.loading("Changing Password")
        try{
            const response = await request("/api/auth/reset/").post(form)
            const data = await response.json()
            if (data?.token){
                setSession(data.token)
                toast.success("Password Changed Successfully", {id: toastId})
                setForm(initials)
            } 
            else{
                toast.error("Check Old Password", {id: toastId})
            }
        }catch(err){
            console.log(err)
            toast.error("An error occurred, retry", {id: toastId})
        }
    }

    return (
    <div>
        <div className="mx-auto rounded-md w-full md:w-2/5 bg-[#0e333d] min-h-[20rem] my-[5rem] text-white py-6 p-5">
            <h1 className="text-center my-4 font-volkolak font-bold text-2xl">Edit Account</h1>
            <form onSubmit={handleSubmit}>                
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="password" className="text-[.8rem] font-bold">OLD PASSWORD</label>
                    <input 
                        type="password"
                        value={form.old_password}  
                        onChange={(e)=> setForm({...form, old_password:e.target.value})}
                        className="w-full px-3 p-2 rounded bg-white text-[#0e333d]"
                        required
                    />
                </div>
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="password" className="text-[.8rem] font-bold">NEW PASSWORD</label>
                    <input 
                        type="password"  
                        value={form.new_password}
                        onChange={(e) => setForm({...form, new_password:e.target.value })}
                        className="w-full px-3 p-2 rounded bg-white text-[#0e333d]"
                        required
                    />
                </div>
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="password" className="text-[.8rem] font-bold">REPEAT NEW PASSWORD</label>
                    <input 
                        type="password"  
                        value={form.repeat_password}
                        onChange={(e) => setForm({...form, repeat_password:e.target.value})}
                        className="w-full px-3 p-2 rounded bg-white text-[#0e333d]"
                        required
                    />
                </div>

                <button 
                    disabled={disabled}
                    className="w-full bg-[#f7b500] text-[#0e333d] font-bold py-2 rounded-md mt-4 disabled:opacity-60"
                >Change Password</button>
            </form>
        </div>
    </div>
  )
}
