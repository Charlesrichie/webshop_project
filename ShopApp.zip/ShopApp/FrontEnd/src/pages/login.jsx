import { useState } from 'react'
import { url} from '../utils'
import { toast } from 'react-hot-toast'
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../store';


const Login = () => {
    const navigate = useNavigate()
    const setSession = useAuth(state => state.setSession)
    const [formdata, setFormdata] = useState({
        username: '',
        password: ''
    })

    const disabled = formdata.username === '' || formdata.password === ''    
    
    const handleSubmit = async(e) => {
        e.preventDefault()
        const toastId = toast.loading("Logging in...")
        try{
            const res = await fetch(url("/api/auth/login/"), {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(formdata)
            })

            const data = await res.json()
            if(data.token){
                setSession(data.token)
                toast.success("Logged in successfully", {id: toastId})
                navigate("/shop")
            }
            else{
                toast.error("Invalid credentials", {id: toastId})
            }
        }catch(err){
            console.log(err)
            toast.error("Something went wrong", {id: toastId})
        }
        
    }    
    return (
        <div className="mx-auto rounded-md w-full md:w-2/5 bg-[#0e333d] min-h-[20rem] my-[5rem] text-white py-6 p-5">
            <h1 className="text-center my-4 font-volkolak font-bold text-2xl">Login</h1>
            <form onSubmit={handleSubmit}>
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="username" className="text-[.8rem] font-bold">USERNAME</label>
                    <input 
                        onChange={(e) => setFormdata({...formdata, username: e.target.value})}
                        type="text" 
                        className="w-full px-3 p-2 rounded bg-white text-[#0e333d]"
                    />
                </div>
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="password" className="text-[.8rem] font-bold">PASSWORD</label>
                    <input 
                        onChange={(e) => setFormdata({...formdata, password: e.target.value})}
                        type="password"  
                        className="w-full px-3 p-2 rounded bg-white text-[#0e333d]"
                    />
                </div>
                <button 
                    disabled={disabled}
                    className="w-full bg-[#f7b500] text-[#0e333d] font-bold py-2 rounded-md mt-4 disabled:opacity-60"
                >Login</button>
                <Link to="/signup" className="text-[#f7b500] text-center block mt-4">Don't have an account? Sign up</Link>
            </form>
        </div>
    )
}

export default Login