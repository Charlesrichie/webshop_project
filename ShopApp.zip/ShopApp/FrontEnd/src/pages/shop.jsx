import Product, { NoProduct } from "../components/general/Product"
import { useState, useEffect} from "react"
import { getSession, url } from "../utils"
import { toast } from "react-hot-toast"
import { useParams } from 'react-router-dom';

const Shop = () =>{
    const [products, setProducts] = useState([])
    const [firstLoad, setFirstLoad] = useState(true)
    const [paginationData, setPaginationData] = useState({
        count: 0,
        next: null,
        previous: null,
    })
    
    // url /shop/:search using react router dom
    const {search} = useParams()

    useEffect(() => {

        const fetchProducts = async () => {
            const session =  getSession()
            
            const res = await fetch(url(search ?
                    `/api/shop/items/?name=${search}&page=1&` :
                    `/api/shop/items/?page=1&`
                    ),
                {
                    method: "GET",
                    headers: {
                        "Authorization": session ?  `Token ${getSession()}` : ""
                    }
                }
            )

            const data = await res.json()
            if (res.status !== 200){
                console.log(data)
                return
            }
            const {count, next, results, previous} = data
            setProducts(results)
            setPaginationData({
                count,
                next,
                previous
            })
            if(firstLoad){
                setFirstLoad(false)
            }
        }
        fetchProducts()

    }, [firstLoad,search])

    const loadMore = async () => {
        if (!paginationData.next) return
        const session =  getSession()
        const res = await fetch(paginationData.next,
            {
                method: "GET",
                headers: {
                    "Authorization": session ?  `Token ${getSession()}` : ""
                }
            }
        )

        const data = await res.json()
        if (res.status !== 200){
            toast.error("Error loading more products")
            return
        }
        const {count, next, results, previous} = data
        setProducts([...products, ...results])
        setPaginationData({
            count,
            next,
            previous
        })
    }


    return (
        <div>
            <h1 className="font-bold text-center text-3xl font-volkolak mb-12">Products For You</h1>
            {products.length > 0 ? 
                <div className="grid grid-cols-1 md:grid-cols-4 my-4 gap-6">
                    {products.map((product) => <Product key={product.id} product={product}/>)}
                </div>
                : <NoProduct firstLoad={firstLoad} />
            }
            {products.length > 0 &&  paginationData.next && <div className="flex my-6 items-center justify-center">
                <button 
                    onClick={loadMore}
                    className="font-bold rounded-xl border px-6 p-2 border-[#0e333d] ">
                    Load more
                </button>
            </div>
            }
            
        </div>
    )
}

export default Shop