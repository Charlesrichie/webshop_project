import { useState } from "react"
import { toast } from "react-hot-toast"
import { url } from "../utils"
import { Link, useNavigate } from "react-router-dom"

const SignUp = () => {
    const navigate = useNavigate()
    const [formData, setFormdata] = useState({
        username : "",
        password : "",
        email : "",
        password_2 : ""
    })
    
    const password_match = formData.password === formData.password_2
    const disabled = formData.username === '' || formData.password === '' || formData.email === '' || formData.password_2 === '' || !password_match
    const handleSubmit = async (e) =>{
        e.preventDefault()
        const toast_id = toast.loading("Creating account...")
        try{
            const res = await fetch(url('/api/auth/signup/'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(
                    Object.fromEntries(
                        Object.entries(formData).filter(([key, value]) => key !== 'password_2')
                    )
                )

            })
            const data = await res.json()
            // check for 400 status code
            if(res.status === 400){
                // handle django validation errors
                const errors = data
                for(const key in errors){
                    toast.error(errors[key], {id: toast_id})
                }
            }
            else if(res.status === 201){
                toast.success("Account created successfully", {id: toast_id})
                navigate('/login')
            }
        }catch(err){
            console.log(err)
            toast.error("Something went wrong", {id: toast_id})
        }
    }
    return(
        <div className="mx-auto rounded-md w-full md:w-2/5 bg-[#0e333d] min-h-[20rem] my-[3rem] text-white py-6 p-5">
            <h1 className="text-center my-4 font-volkolak font-bold text-2xl">Sign Up</h1>
            <form onSubmit={handleSubmit}>
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="email" className="text-[.8rem] font-bold">EMAIL</label>
                    <input 
                        onChange={(e) => setFormdata({...formData, email: e.target.value})}
                        type="email" 
                        className="w-full px-3 p-2 rounded bg-white text-[#0e333d]"
                    />
                </div>
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="username" className="text-[.8rem] font-bold">USERNAME</label>
                    <input 
                        onChange={(e) => setFormdata({...formData, username: e.target.value})}
                        type="text" 
                        className="w-full px-3 p-2 rounded bg-white text-[#0e333d]"
                    />
                </div>
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="password" className="text-[.8rem] font-bold">PASSWORD</label>
                    <input 
                        onChange={(e) => setFormdata({...formData, password: e.target.value})}
                        type="password"  
                        className="w-full px-3 p-2 rounded bg-white text-[#0e333d]"
                    />
                </div>
                <div className="mb-3 flex flex-col space-y-2">
                    <label htmlFor="password" className="text-[.8rem] font-bold">REPEAT PASSWORD</label>
                    <input 
                        onChange={(e) => setFormdata({...formData, password_2: e.target.value})}
                        type="password"  
                        className={`w-full px-3 p-2 rounded bg-white text-[#0e333d]
                            ${password_match ? "outline-[#f7b500] outline-1" : "border-[#ff0000] border-2"}
                        `}
                    />
                </div>
                <button 
                    disabled={disabled}
                    className="w-full bg-[#f7b500] text-[#0e333d] font-bold py-2 rounded-md mt-4 disabled:opacity-60"
                >Sign Up</button>
                <Link to="/login" className="text-[#f7b500] text-center block mt-4">Already have an account?</Link>
            </form>
        </div>
    )
}

export default SignUp