import random
from io import BytesIO
from datetime import timedelta
from django.shortcuts import render, redirect
from django.views import View
from django.core.files.base import ContentFile
from django.utils import timezone
from django.contrib.auth.models import User
from rest_framework.viewsets import ModelViewSet
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.generics import ListAPIView
from rest_framework import status
from .serializers import ProductSerializer, BuyProductSerializer
from .models import Product
from .permissions import IsProductOwner
from placeholder_pics import PlaceholderPic
from drf_spectacular.utils import extend_schema
from django.core.mail import send_mail
from django_filters import rest_framework as filters
from django.contrib import messages

email_template = """Hello {username},
Your product {product_name} has been sold for {price} EUR.
Thank you for using our service.
Best regards,
    Shop.aa
"""


class HomePageView(View):
    """Home page view"""
    template_name = "home.html"
    
    def get(self, request):
        products = Product.objects.all()
        last_week = timezone.now() - timedelta(days=7)
        products_count = products.count()
        products_added_last_week = products.filter(created_at__gte=last_week).count()
        active_users = User.objects.filter(is_active=True).count()
        context = {
            "products": products,
            "products_count": products_count,
            "products_added_last_week": products_added_last_week,
            "active_users": active_users
        }
        return render(request, self.template_name, context)
    
    def generate_users(self):
        """Generate 6 users"""
        for i in range(1,7):
            User.objects.create_user(
                username=f"testuser{i}",
                password=f"pass{i}",
                email=f"testuser{i}@shop.aa"
                )
        return User.objects.filter(username__startswith="testuser")
    
    def empty_db(self):
        """Delete all items"""
        Product.objects.all().delete()
        User.objects.filter(username__startswith="testuser").delete()
        return 
    
    def get_price(self):
        """Generate a random price"""
        return random.randint(100, 1000)
    def get_number(self, a,b):
        return f"{a * 10 + b}" if b == 10 else f"{a}{b}"
    
    def generate_ten_items_per_user(self, users:list[User]):
        """Generate 30 items"""    
        for index, user in enumerate(users):
            for i in range(1, 11):
                p_num = self.get_number(index, i)
                thumbnail = PlaceholderPic(f"P {p_num}")
                thumbnail_io = BytesIO()
                product = Product.objects.create(
                    name=f"Product {p_num}",
                    description=f"Description for product {p_num}",
                    price=self.get_price(),
                    owner=user
                    )
                thumbnail.image.save(thumbnail_io, "PNG")
                product.thumbnail.save(f"product_{p_num}.png", ContentFile(thumbnail_io.getvalue()), save=False)
                product.save()
        return Product.objects.all()

    
    def post(self, request):
        """Delete all items and generate 6 new users and 30 new items"""
        self.empty_db()
        new_users = self.generate_users()
        new_users = new_users[:3]
        self.generate_ten_items_per_user(new_users)
        messages.success(request, "Database has been reset")
        return redirect("home")
    
class ShopFilter(filters.FilterSet):
    """Filter for the shop"""
    name = filters.CharFilter(lookup_expr="icontains")
    class Meta:
        model = Product
        fields = ["name",]


    
class ShopItemsView(ModelViewSet):
    lookup_field = "id"
    lookup_value_regex = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}" # UUID regex
    pagination_class = PageNumberPagination
    model = Product
    filter_backends = (filters.DjangoFilterBackend,)
    filterset_class = ShopFilter
    
    def get_permissions(self):
        """
            Allow anyone to view the list of products
            Only product owners can edit or delete their products
        """
        permission_classes = []
        if self.action in ["update", "partial_update", "destroy"]:
            permission_classes = [IsAuthenticated, IsProductOwner]
        elif self.action in ["list", "retrieve"]:
            permission_classes =  []
        else:
            permission_classes =  [IsAuthenticated, ]
        return [permission() for permission in permission_classes]    
    
    def get_queryset(self):

        """
        List all products without a buyer, from the newest to the oldest
        Exclude products that are owned by the current user
        """
        if self.action != "list":
            return Product.objects.all().order_by("-created_at")
        return Product.objects.filter(buyer=None).order_by("-created_at").exclude(owner=self.request.user.id)
        
    def get_serializer_class(self):
        """Use the ProductSerializer"""
        return ProductSerializer        
    
    def perform_create(self, serializer:Product):
        """Set the owner of the product to the current user"""
        serializer.save(owner=self.request.user)
        return super().perform_create(serializer)
    
    @extend_schema(tags=["Cart"], request=BuyProductSerializer(many=True))
    @action(detail=False, methods=["post"], 
            permission_classes=[IsAuthenticated],
            url_path="buy", url_name="buy")
    def buy_products(self, request):
        """Buy list of products"""
        serializer = BuyProductSerializer(data=request.data, many=True, context={"request": request})
        if serializer.is_valid():
            for product_data in serializer.validated_data:
                product = Product.objects.get(id=product_data["id"])
                product.buyer = request.user
                product.save()
                message = email_template.format(
                    username = product.owner.username,
                    product_name = product.name,
                    price = product.price,
                )
                send_mail(
                    subject="Product Sold",
                    message=message,
                    from_email="shop@aa.com",
                    recipient_list=[product.owner.email, ],
                    fail_silently=False,
                )
                
            return Response({"message": "Products bought successfully"}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
        
@extend_schema(tags=["History"])                
class SaleHistoryView(ListAPIView):
    """List all products owned by the current user for sale"""
    serializer_class = ProductSerializer
    pagination_class = PageNumberPagination
    permission_classes = [IsAuthenticated, ]
    
    def get_queryset(self):
        return Product.objects.filter(owner=self.request.user.id, buyer__isnull=True).order_by("-created_at")

@extend_schema(tags=["History"])
class SoldProductsView(ListAPIView):
    """List all products sold by the current user"""
    serializer_class = ProductSerializer
    pagination_class = PageNumberPagination
    permission_classes = [IsAuthenticated, ]

    def get_queryset(self):
        return Product.objects.filter(owner=self.request.user.id, buyer__isnull=False).order_by("-created_at")

@extend_schema(tags=["History"])
class PurchasedProductsView(ListAPIView):
    """List all products purchased by the current user"""
    serializer_class = ProductSerializer
    pagination_class = PageNumberPagination
    permission_classes = [IsAuthenticated, ]

    def get_queryset(self):
        return Product.objects.filter(buyer=self.request.user.id).order_by("-created_at")
    