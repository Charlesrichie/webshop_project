from rest_framework import serializers
from .models import Product

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ('id', 'name', 'description', 'price', 'thumbnail', 'created_at', 'updated_at', 'owner', 'buyer' )
        read_only_fields = ('id', 'created_at', 'updated_at', 'owner', 'buyer' )
        
class BuyProductSerializer(serializers.Serializer):
    id = serializers.UUIDField()
    price = serializers.DecimalField(max_digits=10, decimal_places=2)
    
    def validate(self, data):
        """update the product with the buyer"""
        try:
            product = Product.objects.get(id=data['id'])
        except Product.DoesNotExist as e:
            raise serializers.ValidationError(
                {
                    "message": "Product does not exist",
                    "price": data["price"],
                    "id": data["id"],
                    "error": "product_error"
                }) from e
        if product.owner == self.context.get("request").user:
            raise serializers.ValidationError(
                {
                    "message": "You cannot buy your own product",
                    "price": product.price,
                    "id": product.id,
                    "error": "own_product"
                }
            )
        
        if product.price != data['price']:
            raise serializers.ValidationError({
                "message": "Price has changed",
                "price": product.price,
                "id": product.id,
                "error": "price_changed"
            })
        if product.buyer:
            raise serializers.ValidationError(
                {
                    "message": "Product has already been bought",
                    "price": product.price,
                    "id": product.id,
                    "error": "product_bought"
                }
            )
        return data
