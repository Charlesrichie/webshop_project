from rest_framework.routers import SimpleRouter
from django.urls import path
from .views import ShopItemsView, SaleHistoryView, SoldProductsView, PurchasedProductsView

router = SimpleRouter()
router.register(r'shop/items', ShopItemsView, basename='shop_items')


urlpatterns = [
    path('shop/history/sale', SaleHistoryView.as_view(), name='shop_history'),
    path('shop/history/sold', SoldProductsView.as_view(), name='shop_sold'),
    path('shop/history/purchased', PurchasedProductsView.as_view(), name='shop_purchased'),
]

urlpatterns += router.urls
