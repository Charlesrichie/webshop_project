from rest_framework import permissions

class IsProductOwner(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Only allow owners to edit or delete their own products
        return obj.owner == request.user