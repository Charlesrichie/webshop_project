from django.db.models.signals import post_delete
from django.dispatch import receiver
from .models import Product

@receiver(post_delete, sender=Product)
def delete_image(sender, instance:Product, **kwargs):
    """Delete image file on `post_delete` signal"""
    if instance.thumbnail:
        instance.thumbnail.delete(save=False)