from rest_framework.routers import SimpleRouter
from .views import Authentication
router = SimpleRouter()
router.register(r'auth', Authentication, basename='auth')

    
urlpatterns = router.urls
